package com.amazecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazecareHospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
