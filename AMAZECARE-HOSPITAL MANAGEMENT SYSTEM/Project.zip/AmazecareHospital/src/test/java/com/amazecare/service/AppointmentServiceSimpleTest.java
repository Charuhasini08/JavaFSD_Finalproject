package com.amazecare.service;

import com.amazecare.entity.Appointment;
import com.amazecare.repository.AppointmentRepository;
import com.amazecare.service.impl.AppointmentServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AppointmentServiceSimpleTest {

    @Mock
    private AppointmentRepository appointmentRepository;

    @InjectMocks
    private AppointmentServiceImpl appointmentService;

    public AppointmentServiceSimpleTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAppointment() {
        Appointment appointment = new Appointment();
        appointment.setPatientName("Test Patient");
        appointment.setDoctorName("Test Doctor");
        

        when(appointmentRepository.save(appointment)).thenReturn(appointment);

        Appointment result = appointmentService.createAppointment(appointment);

        assertNotNull(result);
        assertEquals("Test Patient", result.getPatientName());
        verify(appointmentRepository, times(1)).save(appointment);
    }
}
