package com.amazecare.service;

import com.amazecare.entity.Staff;
import com.amazecare.repository.StaffRepository;
import com.amazecare.service.impl.StaffServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StaffServiceSimpleTest {

    @Mock
    private StaffRepository staffRepository;

    @InjectMocks
    private StaffServiceImpl staffService;

    public StaffServiceSimpleTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateStaff() {
        Staff staff = Staff.builder()
                .name("Ravi Kumar")
                .role("Technician")
                .department("Radiology")
                .contactNumber("9876543210")
                .build();

        when(staffRepository.save(staff)).thenReturn(staff);

        Staff saved = staffService.createStaff(staff);

        assertNotNull(saved);
        assertEquals("Ravi Kumar", saved.getName());
        assertEquals("Technician", saved.getRole());
        verify(staffRepository, times(1)).save(staff);
    }
}
