package com.amazecare.service;

import com.amazecare.entity.Bill;
import com.amazecare.repository.BillRepository;
import com.amazecare.service.impl.BillServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BillServiceSimpleTest {

    @Mock
    private BillRepository billRepository;

    @InjectMocks
    private BillServiceImpl billService;

    public BillServiceSimpleTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateBill() {
        Bill bill = Bill.builder()
                .patientName("Test Patient")
                .billingDate(LocalDate.of(2025, 7, 16))
                .consultationFee(300)
                .medicineCharges(500)
                .otherCharges(200)
                .totalAmount(1000)
                .build();

        when(billRepository.save(bill)).thenReturn(bill);

        Bill saved = billService.createBill(bill);

        assertNotNull(saved);
        assertEquals("Test Patient", saved.getPatientName());
        assertEquals(1000, saved.getTotalAmount());
        verify(billRepository, times(1)).save(bill);
    }
}
