package com.amazecare.service;

import com.amazecare.entity.Patient;
import com.amazecare.repository.PatientRepository;
import com.amazecare.service.impl.PatientServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PatientServiceSimpleTest {

    @Mock
    private PatientRepository patientRepository;

    @InjectMocks
    private PatientServiceImpl patientService;

    public PatientServiceSimpleTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreatePatient() {
        Patient patient = Patient.builder()
                .name("Alice Smith")
                .age(30)
                .gender("Female")
                .contactNumber("9876543210")
                .address("456 Maple Street")
                .medicalHistory("Asthma")
                .build();

        when(patientRepository.save(patient)).thenReturn(patient);

        Patient saved = patientService.createPatient(patient);

        assertNotNull(saved);
        assertEquals("Alice Smith", saved.getName());
        assertEquals(30, saved.getAge());
        verify(patientRepository, times(1)).save(patient);
    }
}
