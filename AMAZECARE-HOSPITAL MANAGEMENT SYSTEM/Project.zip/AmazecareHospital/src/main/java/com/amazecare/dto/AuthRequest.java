package com.amazecare.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthRequest {

    @Schema(description = "Username for the user", example = "admin123")
    private String username;

    @Schema(description = "Password for the user", example = "secret")
    private String password;

}
